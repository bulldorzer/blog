const data = [
    { id:0, title: '신촌 디저트 맛집', good: 13, regiDate:'2024-11-12' },
    { id:1, title: '겨울 방한 아이템', good: 7, regiDate:'2024-12-24' },
    { id:2, title: '리액트 독학', good: 15, regiDate:'2023-12-24' },
    { id:3, title: '텀블러 구입', good: 0, regiDate:'2022-12-24' }
];

export default data

function AddPage(){
    return(
        <div>
            <p>Add Page</p>
        </div>

    )
}
export default AddPage;
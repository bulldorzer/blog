import BasicLayout from "../layout/BasicLayout";

function MainPage(){
    return(
        <BasicLayout>
            <div className="mainPage">
                <h1>mainPage</h1>
            </div>
        </BasicLayout>
    )
}
export default MainPage;
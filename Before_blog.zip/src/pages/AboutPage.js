import BasicLayout from '../layout/BasicLayout'

function AboutPage(){
    return(
        <BasicLayout>
        <div className="aboutPage">
            <h1>aboutPage</h1>
        </div>
        </BasicLayout>
    )
}
export default AboutPage;
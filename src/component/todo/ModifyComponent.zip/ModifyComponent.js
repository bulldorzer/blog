import { useEffect, useState } from "react";
import useCustomMove from '../../hook/useCustomHook'
import ResultModal from "../common/ResultModal";
import { getOne, deleteOne, putOne } from "../../api/todoApi";

const initState = { 
    tno : 0,  
    title : '', 
    writer : '', 
    dueDate : '', 
    complete : false 
}

const ModifyComponent = ({tno}) =>{

    const [todo, setTodo] = useState({...initState})

    const {moveToList, moveToRead} = useCustomMove()
    const [result, setResult] = useState(null)
    
    useEffect(()=>{
        getOne(tno).then(data =>{
            setTodo(data)
        })
    }, [tno])

    // ()=> 실행할문장; 
    // ()=> 리턴될 값; 
    // ()=> ({}) - // 리턴값이 객체 형태인경우
    
    const handleChangeTodo = (e) => {

        const {name, value} = e.target
        
        setTodo( prevTodo => ({
            ...prevTodo, 
            [name]: name=="complete" ? value === "Y" : value
        } ))
    }

    // [name] : key값을 동기적으로 설정
      // name속성이 complete이면, value === "true"의 결과값(true/false을 저장

    const handleClickModify = () => {
    
        putOne(todo).then( data =>{
            console.log("modify result : " + data)
            setResult('Modify')
        })        
    }

    const handleClickDelete = () => {

        deleteOne(tno).then( data => {
            console.log('delete result' + data);
            setResult('Delete')
        })
        
    }

    const closeModal = ()=>{ //  닫기 누르면 페이지 이동
        
        if(result === 'Delete'){
            moveToList()
        } else {
            moveToRead(tno)
        }
    }

    const fields = [
        {title : 'Tno', name : 'tno', value : todo.name, type : 'text', readOnly : true },
        {title : 'Writer', name : 'writer', value : todo.writer, type : 'text', readOnly : true },
        {title : 'Title', name : 'title', value : todo.title, onChange : handleChangeTodo },
        {title : 'Due Date', name : 'dueDate', value : todo.dueDate, onChange: handleChangeTodo, type : 'date'}
    ]

    return (
        <>
            {result&& 
                <ResultModal title={'처리결과'} content={result} cbFn={closeModal}/>}
            <ul>
                {
                    fields.map( field =>( 
                        <LiField key={field.name} {...field} /> 
                    ))
                    
                }
                <li>
                    <span>Complete</span>
                    <span>
                        <label>
                            <input 
                                type="radio" name="complete" 
                                value="Y"
                                onChange={handleChangeTodo} 
                                checked={todo.complete == true}
                                ></input>Yes</label>
                        <label>
                            <input 
                                type="radio" name="complete" 
                                value="N" 
                                onChange={handleChangeTodo} 
                                checked={todo.complete == false}
                            ></input>No</label>
                    </span>
                </li>   
            </ul>
            <div className="btnGroup">
                <button type="button" className="btn" onClick={handleClickDelete}>삭제</button>
                <button type="button" className="btn" onClick={handleClickModify}>수정</button>
            </div>
        </>
    )
}

// 컴포넌트
const LiField = ({title, name, value, onChange, type='text', readOnly = false}) =>  (
    <li>
        <span className="labelWrap">{title}</span>
        <span className="dataWrap">
            <input 
                name={name}
                type={type} 
                value={value} 
                onChange={onChange} 
                readOnly={readOnly}
            />
        </span>
    </li>
)

export default ModifyComponent;

